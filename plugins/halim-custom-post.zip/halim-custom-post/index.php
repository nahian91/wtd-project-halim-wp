<?php

/**
 * Plugin Name: Halim Custom Post
 * Plugin URI: https://www.anahian.com/halim-custom-post
 * Description: A brief description of the Plugin.
 * Version: 1.0
 * Author: Abdullah Nahuan
 * Author URI: https://www.anahian.com/
 */

 


// Custom Posts
function halim_custom_posts() {

    // Slider Custom Post
    register_post_type('sliders', array(
        'labels' => array(
            'name' => __('Sliders', 'halim'),
            'singular_name' => __('Slider', 'halim')
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'custom-fields'),
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-slides'
    ));

    // Services Custom Post
    register_post_type('services', array(
        'labels' => array(
            'name' => __('Services', 'halim'),
            'singular_name' => __('Service', 'halim')
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title', 'editor', 'custom-fields'),
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-calculator'
    ));

    // Counter Custom Post
    register_post_type('counters', array(
        'labels' => array(
            'name' => __('Counters', 'halim'),
            'singular_name' => __('Counter', 'halim')
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title', 'custom-fields'),
    ));

    // Team Custom Post
    register_post_type('teams', array(
        'labels' => array(
            'name' => __('Teams', 'halim'),
            'singular_name' => __('Team', 'halim')
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title', 'thumbnail', 'custom-fields'),
    ));

    // Testimonials Custom Post
    register_post_type('testimonials', array(
        'labels' => array(
            'name' => __('Testimonials', 'halim'),
            'singular_name' => __('Testimonial', 'halim')
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title', 'thumbnail', 'custom-fields'),
    ));

    // Portfolio Custom Post
    register_post_type('portfolio', array(
        'labels' => array(
            'name' => __('Portfolios', 'halim'),
            'singular_name' => __('Portfolio', 'halim')
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'custom-fields'),
    ));

    // Gallery Custom Post
    register_post_type('gallery', array(
        'labels' => array(
            'name' => __('Gallerys', 'halim'),
            'singular_name' => __('Gallery', 'halim')
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title', 'thumbnail', 'custom-fields'),
        'menu_icon' => 'dashicons-slides'
    ));

    register_taxonomy('portfolio-cat', 'portfolio', array(
        'lables' => array(
            'name' => __('Categories', 'halim'),
            'singular_name' => __('Category', 'halim')
        ),
        'hierarchical' => true,
        'show_admin_column' => true
    ));

}
add_action('init', 'halim_custom_posts');